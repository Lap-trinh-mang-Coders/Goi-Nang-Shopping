# Goi-Nang-Shopping
Coffee &amp; Tea House nơi bạn tỉnh táo với hương vị, nhưng say mê khung cảnh Sài Gòn. Từ Thủ Đức nhìn LandMark 81 uy nghi, Bitexco ẩn trong mây, bên trái Cát Lái nhộn nhịp, bên phải Thủ Đức gần gũi, bình yên.
