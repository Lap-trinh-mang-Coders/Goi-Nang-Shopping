package com.example.goinangshopping;

import com.example.goinangshopping.model.Item;
import com.example.goinangshopping.model.ItemCategory;
import com.example.goinangshopping.model.User;
import com.example.goinangshopping.repository.ItemRepository;
import com.example.goinangshopping.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Set;

@Component
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final ItemRepository itemRepository;
    private final PasswordEncoder passwordEncoder;

    public DataInitializer(UserRepository userRepository, ItemRepository itemRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.itemRepository = itemRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) throws Exception {
        // Create an ADMIN user if one doesn't exist
        if (!userRepository.existsByEmail("admin@example.com")) {
            User adminUser = User.builder()
                    .username("admin")
                    .fullname("Admin User")
                    .email("admin@example.com")
                    .phone("0123456789")
                    .password(passwordEncoder.encode("password123"))
                    .roles(Set.of(User.Roles.ADMIN))
                    .build();
            userRepository.save(adminUser);
        }

        // Create a sample item if none exist
        if (itemRepository.count() == 0) {
            Item sampleItem = new Item();
            sampleItem.setName("Classic Milk Tea");
            sampleItem.setPrice(new BigDecimal("25000"));
            sampleItem.setCategory(ItemCategory.FRUIT_TEA);
            sampleItem.setAvailable(true);
            itemRepository.save(sampleItem);
        }
    }
}