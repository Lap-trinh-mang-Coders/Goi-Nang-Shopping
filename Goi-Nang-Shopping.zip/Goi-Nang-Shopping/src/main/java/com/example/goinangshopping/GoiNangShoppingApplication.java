package com.example.goinangshopping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GoiNangShoppingApplication {

    public static void main(String[] args) {
        SpringApplication.run(GoiNangShoppingApplication.class, args);
    }

}
