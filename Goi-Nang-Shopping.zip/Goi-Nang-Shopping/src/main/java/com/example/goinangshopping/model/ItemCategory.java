package com.example.goinangshopping.model;

public enum ItemCategory {
    FRUIT_TEA, SMOOTHIE, ICE_BLENDED, COFFEE, MATCHA, YOGURT, JUICE
}