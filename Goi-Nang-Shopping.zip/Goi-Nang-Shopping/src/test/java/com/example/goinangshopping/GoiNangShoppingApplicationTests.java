package com.example.goinangshopping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GoiNangShoppingApplicationTests {

    @Test
    void contextLoads() {
    }

}
