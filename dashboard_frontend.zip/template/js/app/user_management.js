﻿$(document).ready(function () {
    const token = localStorage.getItem('accessToken');

    if (!token) {
        window.location.href = 'login3.html';
        return;
    }

    const API_URL = '/api/users'; // Sử dụng proxy
    const userTableBody = $('#usersTable tbody');
    const userModal = $('#userModal');
    const userForm = $('#userForm');

    // Hàm tải và hiển thị danh sách người dùng
    function loadUsers() {
        $.ajax({
            url: API_URL,
            method: 'GET',
            headers: { 'Authorization': 'Bearer ' + token },
            success: function (data) {
                userTableBody.empty();
                data.forEach(user => {
                    const roles = user.roles.join(', '); // Hiển thị các quyền
                    userTableBody.append(`
                        <tr data-id="${user.id}">
                            <td>${user.id}</td>
                            <td>${user.username}</td>
                            <td>${user.fullname}</td>
                            <td>${user.email}</td>
                            <td><label class="badge badge-info">${roles}</label></td>
                            <td>
                                <button class="btn btn-sm btn-info edit-btn">Sửa</button>
                                <button class="btn btn-sm btn-danger delete-btn">Xóa</button>
                            </td>
                        </tr>
                    `);
                });
            },
            error: function (err) {
                alert('Lỗi tải danh sách người dùng. Bạn cần có quyền ADMIN.');
            }
        });
    }

    // Hàm reset form
    function resetForm() {
        userForm[0].reset();
        $('#userId').val('');
        userModal.find('.modal-title').text('Thêm người dùng mới');
    }

    // Mở modal để thêm mới
    $('#addNewUserBtn').on('click', function () {
        resetForm();
    });

    // Lưu người dùng (Thêm mới hoặc Cập nhật)
    $('#saveUserBtn').on('click', function () {
        const userData = {
            username: $('#userName').val(),
            fullname: $('#userFullname').val(),
            email: $('#userEmail').val(),
            password: $('#userPassword').val(),
            roles: $('#userRoles').val()
        };

        const userId = $('#userId').val();
        // Cập nhật không gửi password trống
        if (userId && !userData.password) {
            delete userData.password;
        }

        const method = userId ? 'PUT' : 'POST';
        const url = userId ? `${API_URL}/${userId}` : API_URL;

        $.ajax({
            url: url,
            method: method,
            contentType: 'application/json',
            data: JSON.stringify(userData),
            headers: { 'Authorization': 'Bearer ' + token },
            success: function () {
                userModal.modal('hide');
                loadUsers();
            },
            error: function (err) {
                alert('Lỗi khi lưu người dùng.');
            }
        });
    });

    // Mở modal để sửa
    userTableBody.on('click', '.edit-btn', function () {
        resetForm();
        const userId = $(this).closest('tr').data('id');

        $.ajax({
            url: `${API_URL}/${userId}`,
            method: 'GET',
            headers: { 'Authorization': 'Bearer ' + token },
            success: function (user) {
                $('#userId').val(user.id);
                $('#userName').val(user.username);
                $('#userFullname').val(user.fullname);
                $('#userEmail').val(user.email).prop('disabled', true); // Không cho sửa email
                $('#userRoles').val(user.roles);

                userModal.find('.modal-title').text('Chỉnh sửa người dùng');
                userModal.modal('show');
            }
        });
    });

    // Xóa người dùng
    userTableBody.on('click', '.delete-btn', function () {
        const userId = $(this).closest('tr').data('id');

        if (confirm('Bạn có chắc chắn muốn xóa người dùng này?')) {
            $.ajax({
                url: `${API_URL}/${userId}`,
                method: 'DELETE',
                headers: { 'Authorization': 'Bearer ' + token },
                success: function () {
                    alert('Đã xóa người dùng thành công!');
                    loadUsers();
                },
                error: function (err) {
                    alert('Lỗi khi xóa người dùng.');
                }
            });
        }
    });

    // Tải danh sách người dùng khi trang được mở
    loadUsers();
});